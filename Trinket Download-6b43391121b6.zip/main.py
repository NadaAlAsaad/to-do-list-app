tasks = []
print(" WELCOME TO ️TO DO LIST APP: ")
print('''
1. Add a new task
2. Delete a task
3. Show list tasks
4. Mark completed task
5. Edit task
6. Exiting the application
''')

while True:
    numbers = ["1", "2", "3", "4", "5", "6"]
    print("What would you like to do ?(select the NUMBER that matches the task)")
    tasknumber = input().strip()
    if not tasknumber.isdigit():
        print(" Invalid input > Try again ")
    elif tasknumber == "1":
        print(" Enter the task to add :")
        adding = input().strip()
        tasks.append(adding)
        print(" Your list : ")
        #I tried to print the tasks with their numbers and found it  and I  use it.
        # and this an example about enumerate:
         # fruits = ['apple', 'banana', 'cherry']
         #for index, fruit in enumerate(fruits):
           # print(index, fruit)
        for i, x in enumerate(tasks, 1):
          print(str(i) + " : " + str(x))
        print("DONE :) ")
    elif tasknumber in ["2", "3", "4", "5"] and not tasks:
        print(" Your list is empty. Please add a task first.")
    elif tasknumber == "2":
        while True:
            print(" Your list :")
            for i, x in enumerate(tasks, 1):
                  print(str(i) + " : " + str(x))
            print(" Enter the task NUMBER to remove it :")
            removing = input().strip()
            if removing.isdigit() and 1 <= int(removing) <= len(tasks):
                del tasks[(int(removing)-1)]
                print(" Your list after modification :")
                for i, x in enumerate(tasks, 1):
                  print(str(i) + " : " + str(x))
                print("DONE :) ")
                break
            else:
                print(" Please enter a correct value.")
    elif tasknumber == "3":
        print(" Your list :")
        for i, x in enumerate(tasks, 1):
          print(str(i) + " : " + str(x))
        print("DONE :) ")
    elif tasknumber == "4":
        while True:
            print(" Your list :")
            for i, x in enumerate(tasks, 1):
                  print(str(i) + " : " + str(x))
            print(" Please enter the NUMBER that matches the completed task. ")
            marking = input().strip()
            if marking.isdigit() and 1 <= int(marking) <= len(tasks):
                tasks[int(marking) - 1] += " DONE! ✔️ "
                print(" Your list after modification :")
                for i, x in enumerate(tasks, 1):
                  print(str(i) + " : " + str(x))
                print("DONE :) ")
                break
            else:
                print(" Please enter a correct value. ")
    elif tasknumber == "5":
        while True:
            print(" Your list : ")
            for i, x in enumerate(tasks, 1):
              print(str(i) + " : " + str(x))
            print(" Enter the task NUMBER to edit :")
            editing = input().strip()
            if editing.isdigit() and 1 <= int(editing) <= len(tasks):
                print(" Enter the new task :")
                new_task = input().strip()
                tasks[int(editing) - 1] = new_task
                print(" Your list after modification :")
                for i, x in enumerate(tasks, 1):
                  print(str(i) + " : " + str(x))
                print("DONE :) ")
                break
            else:
                print(" Please enter a correct value.")
    elif tasknumber == "6":
        print(" Exiting the application. Goodbye! ")
        break
    else:
        print("Invalid option. Please try again.")